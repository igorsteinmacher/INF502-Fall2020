file_handle = open("data.csv", "a+")
write = "Text with\na line break"

content = file_handle.write(write+"\n")
file_handle.close()

