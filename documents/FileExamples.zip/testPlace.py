file_handle = open('data.csv', 'r')
content = file_handle.read()
print (content)
file_handle.close()

