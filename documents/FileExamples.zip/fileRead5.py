import csv

with open('data.csv', 'r') as csv_file:
	csv_read = csv.reader(csv_file, delimiter=",")
	for line in csv_read:
		print(line)
