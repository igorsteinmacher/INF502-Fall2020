#this is just an example, do not freak out
def calculate_this(operator, num1, num2):
   print 'my knowledge is limited'     
