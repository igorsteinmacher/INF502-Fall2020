import csv
write = [["Line_number", "name","address","age"],["1", "Igor","12 \"abc\" road","23"]]

file_handle = open("data.csv", "w")
csv_writer = csv.writer(file_handle, delimiter=",", quotechar='"')

csv_writer.writerows(write)
