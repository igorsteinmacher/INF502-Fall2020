file_handle = open('data.csv', 'r')
lines = file_handle.readlines()
print(lines)
file_handle.close()
